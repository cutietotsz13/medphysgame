// Checks public/data/questions.json for mistakes before you deploy: `npm run validate`
import { readFile } from "node:fs/promises";

const file = new URL("../public/data/questions.json", import.meta.url);
let data;
try {
  data = JSON.parse(await readFile(file, "utf8"));
} catch (e) {
  console.error(`✖ questions.json is not valid JSON: ${e.message}`);
  process.exit(1);
}

const problems = [];
const ids = new Set();
if (!Array.isArray(data.modules) || !data.modules.length) problems.push('"modules" must be a non-empty array.');
for (const [mi, m] of (data.modules || []).entries()) {
  const where = `module ${mi + 1} (${m.id || "no id"})`;
  if (!m.id || !m.title) problems.push(`${where}: needs "id" and "title".`);
  if (!Array.isArray(m.levels) || !m.levels.length) problems.push(`${where}: needs at least one level.`);
  for (const [li, l] of (m.levels || []).entries()) {
    if (l.id === undefined) problems.push(`${where} level ${li + 1}: missing "id".`);
    if (!Array.isArray(l.questions) || !l.questions.length) problems.push(`${where} level ${li + 1}: needs at least one question.`);
    for (const [qi, q] of (l.questions || []).entries()) {
      const w = `${where} level ${li + 1} question ${qi + 1}`;
      if (!q.id) problems.push(`${w}: missing "id".`);
      else if (ids.has(q.id)) problems.push(`${w}: duplicate id "${q.id}".`);
      else ids.add(q.id);
      if (!q.question) problems.push(`${w}: missing "question".`);
      if (!Array.isArray(q.options) || q.options.length < 2) problems.push(`${w}: needs at least 2 options.`);
      else if (!Number.isInteger(q.answer) || q.answer < 0 || q.answer >= q.options.length) problems.push(`${w}: "answer" must be a 0-based index into "options".`);
      if (!q.explanation) problems.push(`${w}: (warning) no "explanation".`);
    }
  }
}

const errors = problems.filter((p) => !p.includes("(warning)"));
problems.forEach((p) => console.log((p.includes("(warning)") ? "⚠ " : "✖ ") + p));
const qCount = ids.size;
if (errors.length) { console.error(`\n${errors.length} problem(s) found.`); process.exit(1); }
console.log(`✔ questions.json OK: ${data.modules.length} modules, ${qCount} questions.`);
