# Medical Physics Quest

An educational browser game for medical physics. The home screen **is your original dashboard artwork** (`public/assets/dashboard.png`, cropped pixel-for-pixel from the supplied UI image) with invisible, precisely positioned buttons over every visible control. All other screens are built in HTML/CSS in the same visual language, reusing illustrations cut from the same artwork.

- 4 modules × 2 levels × 5 questions (40 questions), each with an explanation
- Instant feedback, scoring, 0–3 stars per level, level unlocking, 10 badges, results summary with answer review
- Leaderboard (This Month / All Time / My Rank) for all player profiles on the device
- Resources (key concepts, guidelines, case studies, video libraries) and About/disclaimer
- Progress saved in browser `localStorage`; keyboard play (A–D / 1–4, Enter)
- No build step, no dependencies: a static site that deploys to Vercel as-is

## Run locally

Requires Node.js 18+.

```bash
npm run dev          # http://localhost:3000
```

Any static server also works (e.g. `python3 -m http.server -d public 3000`). Opening `index.html` straight from disk won't work, because browsers block loading the question file from `file://`; the game shows an error explaining this.

## Editing questions (for educators)

All questions are in `public/data/questions.json`; learning materials are in `public/data/resources.json`. No code changes are needed.

```json
{
  "id": "rt-1-1",                     // unique across the file
  "topic": "Dose units and definitions",
  "question": "What is the SI unit of absorbed dose?",
  "options": ["Gray (Gy)", "Sievert (Sv)", "Becquerel (Bq)", "Roentgen (R)"],
  "answer": 0,                        // 0-based index of the correct option
  "explanation": "Shown after the player answers."
}
```

- Add a question: append it to a level's `questions` array.
- Add a level: append `{ "id": 3, "title": "...", "description": "...", "questions": [...] }` to a module's `levels`.
- `settings.shuffleOptions` (default `true`) shuffles answer order each attempt, so the correct answer can always be listed first.
- `settings.starThresholds` and `settings.unlockNextLevelMinStars` control scoring and unlocking.
- Check your edits before deploying: `npm run validate` (also runs automatically on Vercel; a broken file fails the build instead of breaking the live game).

The home dashboard card counter shows `x/total` for each module. The artwork reads "0/10"; when progress is 0 and a module has 10 questions, nothing is drawn over the art. Otherwise a small overlay matching the card colour shows the live value.

The four module cards on the home artwork map to module ids `rt`, `di`, `rp`, `qc`. Keep those ids; you can add more modules, which will appear on the Missions, Leaderboard and Resources screens (the home artwork has only four cards).

## Deploy to Vercel

### Option A: GitHub + Vercel (recommended)

1. Create a new GitHub repository and push this folder:
   ```bash
   git init
   git add .
   git commit -m "Medical Physics Quest"
   git branch -M main
   git remote add origin https://github.com/<you>/medical-physics-quest.git
   git push -u origin main
   ```
2. In Vercel, choose **Add New → Project**, then **Import** the repository.
3. Framework preset: **Other**. Vercel reads `vercel.json`: build command `npm run build` (runs the question validator), output directory `public`. No environment variables are needed.
4. Click **Deploy**. Each push to `main` redeploys; pull requests get preview URLs.

### Option B: Vercel CLI

```bash
npm i -g vercel
vercel          # preview deployment
vercel --prod   # production
```

## Project structure

```
public/
  index.html            page shell
  css/styles.css        all styles
  js/app.js             router, screens, game logic, badges
  js/store.js           localStorage persistence (multiple players per device)
  js/icons.js           inline SVG icons
  data/questions.json   question bank (edit me)
  data/resources.json   learning materials (edit me)
  assets/               dashboard.png (original artwork) + illustrations cropped from it
scripts/
  dev-server.mjs        zero-dependency local server
  validate-questions.mjs
vercel.json
```

## Notes and limits

- **Leaderboard data is local.** It ranks the player profiles stored in this browser (useful on a shared lab PC). No fabricated players are shown. A cross-device leaderboard needs a backend; a straightforward route is Vercel + a hosted database (e.g. Supabase or Neon Postgres) with authentication, storing one row per attempt. That would add environment variables such as `DATABASE_URL` and auth keys; none are needed for this version.
- **Artwork resolution.** The dashboard area in the supplied image is 977 × 632 px, so on large screens it is scaled up and looks slightly soft. For sharper display, export the dashboard at 2× or 3× (same composition) and replace `public/assets/dashboard.png`; hotspots are percentage-based and stay aligned as long as the aspect ratio is unchanged.
- **Mobile.** The artwork keeps its landscape aspect ratio (no cropping or stretching). In portrait, large quick-link buttons appear beneath it; landscape gives the biggest dashboard.
- Fonts load from Google Fonts (Nunito) with a system fallback.

## Disclaimer

For education and training only. Not clinical guidance; always follow local regulations, institutional procedures and your qualified medical physicist.
