/* Medical Physics Quest — local persistence (browser localStorage).
   Several players can share one device (e.g. a teaching lab PC); each has their own progress. */
(function () {
  const KEY = "mpq.v1";
  let memory = null; // fallback when storage is blocked (private mode, sandboxed iframes)
  let storageOk = true;

  function uid() {
    return "p" + Math.random().toString(36).slice(2, 9) + Date.now().toString(36).slice(-4);
  }

  function fresh() {
    const id = uid();
    return {
      version: 1,
      currentPlayerId: id,
      players: { [id]: newPlayer(id, "MP Explorer") },
      lastResult: null
    };
  }

  function newPlayer(id, name) {
    return { id, name, createdAt: Date.now(), best: {}, attempts: [], badges: {} };
  }

  function load() {
    if (memory) return memory;
    try {
      const raw = localStorage.getItem(KEY);
      const data = raw ? JSON.parse(raw) : null;
      memory = data && data.players && data.players[data.currentPlayerId] ? data : fresh();
    } catch (e) {
      storageOk = false;
      memory = memory || fresh();
    }
    return memory;
  }

  function save() {
    try {
      localStorage.setItem(KEY, JSON.stringify(memory));
      storageOk = true;
    } catch (e) {
      storageOk = false;
    }
  }

  const Store = {
    get storageOk() { load(); return storageOk; },
    data() { return load(); },
    player() { const d = load(); return d.players[d.currentPlayerId]; },
    players() { return Object.values(load().players); },
    switchPlayer(id) { const d = load(); if (d.players[id]) { d.currentPlayerId = id; save(); } },
    createPlayer(name) {
      const d = load(); const id = uid();
      d.players[id] = newPlayer(id, name); d.currentPlayerId = id; save(); return d.players[id];
    },
    rename(name) { this.player().name = name; save(); },
    deletePlayer(id) {
      const d = load();
      delete d.players[id];
      if (!Object.keys(d.players).length) { memory = fresh(); save(); return; }
      if (d.currentPlayerId === id) d.currentPlayerId = Object.keys(d.players)[0];
      save();
    },
    resetProgress() { const p = this.player(); p.best = {}; p.attempts = []; p.badges = {}; load().lastResult = null; save(); },

    /** Record a finished level attempt and return { improved, previousBest }. */
    recordAttempt(attempt) {
      const p = this.player();
      const key = attempt.moduleId + "-" + attempt.levelId;
      const prev = p.best[key] || null;
      p.attempts.push({
        moduleId: attempt.moduleId, levelId: attempt.levelId,
        correct: attempt.correct, total: attempt.total, stars: attempt.stars,
        seconds: attempt.seconds, at: attempt.at
      });
      if (p.attempts.length > 500) p.attempts = p.attempts.slice(-500);
      const better = !prev || attempt.correct > prev.correct || (attempt.correct === prev.correct && attempt.seconds < prev.seconds);
      if (better) {
        p.best[key] = {
          correct: attempt.correct, total: attempt.total, stars: attempt.stars, seconds: attempt.seconds, at: attempt.at,
          answers: attempt.answers.map(a => ({ id: a.id, correct: a.correct }))
        };
      }
      save();
      return { improved: !!prev && attempt.correct > prev.correct, previousBest: prev };
    },
    awardBadges(ids) {
      const p = this.player(); const added = [];
      ids.forEach(id => { if (!p.badges[id]) { p.badges[id] = Date.now(); added.push(id); } });
      if (added.length) save();
      return added;
    },
    setLastResult(r) { load().lastResult = r; save(); },
    lastResult() { return load().lastResult; }
  };

  window.MPQStore = Store;
})();
