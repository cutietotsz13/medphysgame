/* Medical Physics Quest — application (hash router + screens).
   Question content lives in data/questions.json; learning materials in data/resources.json. */
(function () {
  "use strict";
  const Store = window.MPQStore;
  const I = window.MPQIcons;
  const view = document.getElementById("view");
  const topbar = document.getElementById("topbar");
  const modalRoot = document.getElementById("modal-root");
  const toastRoot = document.getElementById("toast-root");

  /* ---------- artwork geometry (pixels of assets/dashboard.png, 977 × 632) ---------- */
  const ART_W = 977, ART_H = 632;
  const DEFAULT_NAME = "MP Explorer";
  const HOTSPOTS = [
    { id: "logo", label: "Medical Physics Quest home", box: [4, 2, 238, 61], to: "#/home", cls: "quiet" },
    { id: "nav-home", label: "Home", box: [292, 8, 86, 51], to: "#/home" },
    { id: "nav-play", label: "Play", box: [393, 10, 60, 49], to: "#/missions" },
    { id: "nav-leaderboard", label: "Leaderboard", box: [469, 10, 94, 49], to: "#/leaderboard" },
    { id: "nav-resources", label: "Resources", box: [582, 10, 77, 49], to: "#/resources" },
    { id: "nav-about", label: "About", box: [686, 10, 56, 49], to: "#/about" },
    { id: "profile", label: "Player profile", box: [805, 6, 124, 56], action: "profile" },
    { id: "start", label: "Start game", box: [378, 286, 242, 53], to: "#/missions", cls: "round" },
    { id: "card-rt", label: "Radiation Therapy missions", box: [13, 355, 229, 217], to: "#/missions/rt", cls: "card" },
    { id: "card-di", label: "Diagnostic Imaging missions", box: [249, 355, 233, 217], to: "#/missions/di", cls: "card" },
    { id: "card-rp", label: "Radiation Protection missions", box: [490, 355, 233, 217], to: "#/missions/rp", cls: "card" },
    { id: "card-qc", label: "Quality Control missions", box: [731, 355, 236, 217], to: "#/missions/qc", cls: "card" },
    { id: "play-rt", label: "Play Radiation Therapy", box: [153, 525, 82, 37], play: "rt", cls: "round" },
    { id: "play-di", label: "Play Diagnostic Imaging", box: [392, 525, 82, 37], play: "di", cls: "round" },
    { id: "play-rp", label: "Play Radiation Protection", box: [630, 525, 84, 37], play: "rp", cls: "round" },
    { id: "play-qc", label: "Play Quality Control", box: [874, 525, 86, 37], play: "qc", cls: "round" },
    { id: "f-track", label: "Track your progress", box: [24, 586, 148, 38], to: "#/leaderboard/me", cls: "quiet" },
    { id: "f-badges", label: "Earn badges", box: [195, 586, 112, 38], to: "#/leaderboard/me", cls: "quiet" },
    { id: "f-challenge", label: "Challenge your colleagues", box: [334, 586, 184, 38], to: "#/leaderboard", cls: "quiet" },
    { id: "f-skills", label: "Strengthen real-world skills", box: [554, 586, 176, 38], to: "#/resources", cls: "quiet" },
    { id: "f-future", label: "Build a safer, better future", box: [764, 586, 172, 38], to: "#/about", cls: "quiet" }
  ];
  // progress text + bar positions on each module card in the artwork
  const CARD_PROGRESS = {
    rt: { text: [50, 537, 33, 18], bar: [88, 541, 57, 10], bg: "rgb(2,41,117)", fill: "linear-gradient(90deg,#4fb6ff,#8fd3ff)" },
    di: { text: [288, 537, 33, 18], bar: [322, 541, 61, 10], bg: "rgb(3,68,57)", fill: "linear-gradient(90deg,#30e58f,#8dffc6)" },
    rp: { text: [524, 537, 34, 18], bar: [561, 541, 59, 10], bg: "rgb(106,40,8)", fill: "linear-gradient(90deg,#ffb347,#ffd98f)" },
    qc: { text: [767, 537, 33, 18], bar: [802, 541, 58, 10], bg: "rgb(39,7,107)", fill: "linear-gradient(90deg,#b77bff,#ddb9ff)" }
  };
  const PROFILE_NAME_BOX = [866, 12, 76, 18];
  const PROFILE_LEVEL_BOX = [870, 31, 54, 20];

  const THEMES = { blue: "rt", green: "di", orange: "rp", purple: "qc" };
  const BADGE_COLORS = { rt: "#1f8bff", di: "#19c06c", rp: "#ff8a1c", qc: "#9b4dff" };

  /* ---------- state ---------- */
  let DATA = null;       // questions.json
  let RES = null;        // resources.json
  let session = null;    // active mission attempt
  let lastModule = "rt";
  let suppressGuard = false;

  /* ---------- helpers ---------- */
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  const pct = (v, total) => (v / total) * 100;
  const boxStyle = ([x, y, w, h]) => `left:${pct(x, ART_W)}%;top:${pct(y, ART_H)}%;width:${pct(w, ART_W)}%;height:${pct(h, ART_H)}%`;
  const fmtTime = (s) => `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
  const fmtLong = (s) => (s >= 60 ? `${Math.floor(s / 60)} min ${s % 60} sec` : `${s} sec`);
  const starsHtml = (n, max = 3, cls = "") => `<span class="stars ${cls}" role="img" aria-label="${n} of ${max} stars">${Array.from({ length: max }, (_, i) => `<span class="${i < n ? "star-on" : "star-off"}">${I.star}</span>`).join("")}</span>`;
  const mod = (id) => DATA.modules.find((m) => m.id === id);
  const themeCls = (m) => "t-" + (THEMES[m.theme] || m.id);
  const levelKey = (m, l) => `${m.id}-${l.id}`;
  const best = (m, l) => Store.player().best[levelKey(m, l)] || null;
  const moduleTotal = (m) => m.levels.reduce((a, l) => a + l.questions.length, 0);
  const moduleMastered = (m) => m.levels.reduce((a, l) => a + (best(m, l) ? best(m, l).correct : 0), 0);
  const unlockMin = () => (DATA.settings && Number.isFinite(DATA.settings.unlockNextLevelMinStars) ? DATA.settings.unlockNextLevelMinStars : 1);
  const isUnlocked = (m, idx) => idx === 0 || ((best(m, m.levels[idx - 1]) || { stars: 0 }).stars >= unlockMin());
  const totalStars = () => DATA.modules.reduce((a, m) => a + m.levels.reduce((b, l) => b + (best(m, l) ? best(m, l).stars : 0), 0), 0);
  const playerLevel = () => 1 + Math.floor(totalStars() / 3);

  function starsFor(correct, total) {
    const p = total ? (correct / total) * 100 : 0;
    const t = (DATA.settings && DATA.settings.starThresholds) || [{ minPercent: 90, stars: 3 }, { minPercent: 70, stars: 2 }, { minPercent: 50, stars: 1 }];
    const hit = [...t].sort((a, b) => b.minPercent - a.minPercent).find((r) => p >= r.minPercent);
    return hit ? hit.stars : 0;
  }
  function nextPlayableLevel(m) {
    let target = m.levels[0];
    for (let i = 0; i < m.levels.length; i++) {
      if (!isUnlocked(m, i)) break;
      const b = best(m, m.levels[i]);
      target = m.levels[i];
      if (!b || b.stars < 3) return target;
    }
    return target;
  }
  function shuffle(a) { for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
  function go(hash) { if (location.hash === hash) render(); else location.hash = hash; }
  function toast(msg) {
    const t = document.createElement("div"); t.className = "toast"; t.textContent = msg; toastRoot.appendChild(t);
    setTimeout(() => t.remove(), 3200);
  }

  /* ---------- badges ---------- */
  const BADGES = [
    { id: "first", name: "First Mission", desc: "Complete your first mission.", icon: "medal", color: "#1f8bff", test: (c) => c.attempt },
    { id: "perfect", name: "Perfect Score", desc: "Answer every question in a level correctly.", icon: "star", color: "#f5a400", test: (c) => c.attempt && c.attempt.correct === c.attempt.total },
    { id: "quick", name: "Quick Thinker", desc: "Earn 2★ or more in under 60 seconds.", icon: "bolt", color: "#19c06c", test: (c) => c.attempt && c.attempt.stars >= 2 && c.attempt.seconds < 60 },
    { id: "comeback", name: "Comeback", desc: "Beat your previous best on a level.", icon: "retry", color: "#9b4dff", test: (c) => c.improved },
    { id: "spec-rt", name: "Radiotherapy Specialist", desc: "Pass every Radiation Therapy level.", icon: "atom", color: BADGE_COLORS.rt, test: () => modulePassed("rt") },
    { id: "spec-di", name: "Imaging Specialist", desc: "Pass every Diagnostic Imaging level.", icon: "scan", color: BADGE_COLORS.di, test: () => modulePassed("di") },
    { id: "spec-rp", name: "Protection Specialist", desc: "Pass every Radiation Protection level.", icon: "radiation", color: BADGE_COLORS.rp, test: () => modulePassed("rp") },
    { id: "spec-qc", name: "QC Specialist", desc: "Pass every Quality Control level.", icon: "gauge", color: BADGE_COLORS.qc, test: () => modulePassed("qc") },
    { id: "champion", name: "Safety Champion", desc: "Pass every level in every module.", icon: "shield", color: "#e5484d", test: () => DATA.modules.every((m) => modulePassed(m.id)) },
    { id: "master", name: "Quest Master", desc: "Earn 3★ on every level.", icon: "trophy", color: "#e0a800", test: () => DATA.modules.every((m) => m.levels.every((l) => (best(m, l) || {}).stars === 3)) }
  ];
  function modulePassed(id) { const m = mod(id); return !!m && m.levels.every((l) => (best(m, l) || { stars: 0 }).stars >= 1); }
  const badgeHtml = (b, on = true, lg = false) => `<span class="badge ${on ? "" : "off"} ${lg ? "lg" : ""}" style="--bc:${b.color}" title="${esc(b.name)}">${I[b.icon]}</span>`;

  /* ---------- data loading + validation ---------- */
  function validate(d) {
    const problems = [];
    if (!d || !Array.isArray(d.modules) || !d.modules.length) return ["questions.json must contain a non-empty \"modules\" array."];
    const ids = new Set();
    d.modules.forEach((m, mi) => {
      const where = `module ${mi + 1} (${m.id || "no id"})`;
      if (!m.id || !m.title) problems.push(`${where}: needs "id" and "title".`);
      if (!Array.isArray(m.levels) || !m.levels.length) problems.push(`${where}: needs at least one level.`);
      (m.levels || []).forEach((l, li) => {
        if (!Array.isArray(l.questions) || !l.questions.length) problems.push(`${where} level ${li + 1}: needs at least one question.`);
        (l.questions || []).forEach((q, qi) => {
          const w = `${where} level ${li + 1} question ${qi + 1}`;
          if (!q.id) problems.push(`${w}: missing "id".`); else if (ids.has(q.id)) problems.push(`${w}: duplicate id "${q.id}".`); else ids.add(q.id);
          if (!q.question) problems.push(`${w}: missing "question" text.`);
          if (!Array.isArray(q.options) || q.options.length < 2) problems.push(`${w}: needs at least 2 options.`);
          else if (!Number.isInteger(q.answer) || q.answer < 0 || q.answer >= q.options.length) problems.push(`${w}: "answer" must be the index (0-based) of the correct option.`);
        });
      });
    });
    return problems;
  }
  async function fetchJson(url) {
    const r = await fetch(url, { cache: "no-cache" });
    if (!r.ok) throw new Error(`${url} returned HTTP ${r.status}`);
    return r.json();
  }
  async function boot() {
    try {
      const [q, r] = await Promise.all([fetchJson("data/questions.json"), fetchJson("data/resources.json").catch(() => null)]);
      const problems = validate(q);
      if (problems.length) return renderError("The question file has problems", problems);
      DATA = q; RES = r;
      window.addEventListener("hashchange", onHashChange);
      render();
    } catch (e) {
      const fileHint = location.protocol === "file:" ? ["This page was opened directly from disk. Browsers block loading the question file that way — run a local server instead (see README: npm run dev)."] : [];
      renderError("Could not load the game content", [...fileHint, String(e.message || e)]);
    }
  }
  function renderError(title, lines) {
    document.body.classList.remove("is-home"); topbar.hidden = true;
    view.innerHTML = `<div class="state-screen" role="alert"><h2>${esc(title)}</h2>${lines.map((l) => `<p>${esc(l)}</p>`).join("")}<button class="btn yellow" id="retry-load">${I.retry} Try again</button></div>`;
    document.getElementById("retry-load").onclick = () => { view.innerHTML = `<div class="state-screen" role="status"><div class="spinner"></div><p>Loading…</p></div>`; boot(); };
  }

  /* ---------- router ---------- */
  function parse() {
    const parts = (location.hash.replace(/^#\/?/, "") || "home").split("/").filter(Boolean);
    return { name: parts[0] || "home", args: parts.slice(1) };
  }
  function onHashChange(e) {
    // leaving an unfinished mission → ask first
    if (session && !session.finished && !suppressGuard && session.answers.length > 0 && !location.hash.startsWith("#/play/")) {
      const target = location.hash;
      history.replaceState(null, "", session.hash);
      return confirmLeave(target);
    }
    suppressGuard = false;
    render();
  }
  function render() {
    const { name, args } = parse();
    if (!(name === "play" && session && session.hash === location.hash && !session.finished)) stopTimer();
    if (name !== "play") session = session && session.finished ? session : null;
    document.body.classList.toggle("is-home", name === "home");
    closeModal();
    const screens = { home: renderHome, missions: renderMissions, play: renderPlay, results: renderResults, leaderboard: renderLeaderboard, resources: renderResources, about: renderAbout };
    (screens[name] || renderHome)(args);
    window.scrollTo(0, 0);
    if (name !== "home") view.focus({ preventScroll: true });
  }

  /* ---------- shared header for extended screens ---------- */
  function renderTopbar(active) {
    topbar.hidden = false;
    const p = Store.player();
    const items = [["home", "Home", I.home, "#/home"], ["play", "Play", I.play_nav, "#/missions"], ["leaderboard", "Leaderboard", I.trophy, "#/leaderboard"], ["resources", "Resources", I.book, "#/resources"], ["about", "About", I.info, "#/about"]];
    topbar.innerHTML = `
      <a class="brand" href="#/home" aria-label="Medical Physics Quest home"><img src="assets/logo.png" alt="Medical Physics Quest"></a>
      <nav class="nav" aria-label="Main">${items.map(([k, l, ic, h]) => `<a href="${h}" ${k === active ? 'aria-current="page"' : ""}>${ic}<span>${l}</span></a>`).join("")}</nav>
      <button class="profile-btn" id="profile-btn" aria-label="Player profile: ${esc(p.name)}, level ${playerLevel()}"><img src="assets/avatar.png" alt=""><span class="who"><span class="name">${esc(p.name)}</span><span class="pill">Level ${playerLevel()}</span></span></button>`;
    document.getElementById("profile-btn").onclick = openProfile;
  }

  /* ================= HOME (original artwork) ================= */
  function renderHome() {
    topbar.hidden = true;
    const p = Store.player();
    const overlays = DATA.modules.filter((m) => CARD_PROGRESS[m.id]).map((m) => {
      const done = moduleMastered(m), total = moduleTotal(m), g = CARD_PROGRESS[m.id];
      if (done === 0 && total === 10) return ""; // artwork already shows 0/10
      const [bx, by, bw, bh] = g.bar;
      const fillW = Math.max(0, Math.min(1, done / total)) * bw;
      return `<div class="ov ov-text" style="${boxStyle(g.text)};background:${g.bg}">${done}/${total}</div>` +
        (fillW > 0 ? `<div class="ov ov-fill" style="${boxStyle([bx, by, Math.max(fillW, bh), bh])};background:${g.fill}"></div>` : "");
    }).join("");
    const lvl = playerLevel();
    const profileOv = (p.name !== DEFAULT_NAME ? `<div class="ov ov-name" style="${boxStyle(PROFILE_NAME_BOX)}">${esc(p.name)}</div>` : "") +
      (lvl !== 1 ? `<div class="ov ov-level" style="${boxStyle(PROFILE_LEVEL_BOX)}">Level ${lvl}</div>` : "");
    const spots = HOTSPOTS.map((h) => `<button type="button" class="hs ${h.cls || ""}" style="${boxStyle(h.box)}" data-hs="${h.id}" aria-label="${esc(h.label)}" title="${esc(h.label)}"></button>`);
    // card hotspots first so the Play buttons sit on top of them
    const order = [...spots.filter((s) => s.includes('data-hs="card-')), ...spots.filter((s) => !s.includes('data-hs="card-'))];
    view.innerHTML = `
      <div class="dash-wrap">
        <div class="dash">
          <img class="dash-art" src="assets/dashboard.png" width="977" height="632" alt="Medical Physics Quest dashboard: Learn, Solve, Apply, Level Up. Module cards for Radiation Therapy, Diagnostic Imaging, Radiation Protection and Quality Control.">
          ${overlays}${profileOv}
          ${order.join("")}
        </div>
        <div class="home-extra">
          <p class="hint">Tip: rotate your device for a larger dashboard. Quick links:</p>
          <div class="quick">
            <a class="btn yellow" href="#/missions">${I.play} Start Game</a>
            <a class="btn" href="#/leaderboard">${I.trophy} Leaderboard</a>
            <a class="btn ghost" href="#/resources">${I.book} Resources</a>
            <a class="btn ghost" href="#/about">${I.info} About</a>
          </div>
        </div>
      </div>`;
    view.querySelectorAll(".hs").forEach((b) => {
      const h = HOTSPOTS.find((x) => x.id === b.dataset.hs);
      b.addEventListener("click", (e) => {
        e.stopPropagation();
        if (h.action === "profile") return openProfile();
        if (h.play) { const m = mod(h.play); if (m) return go(`#/play/${m.id}/${nextPlayableLevel(m).id}`); }
        if (h.to) go(h.to);
      });
    });
  }

  /* ================= MISSIONS ================= */
  function moduleTabs(activeId, base) {
    return `<div class="mod-tabs" role="tablist" aria-label="Modules">${DATA.modules.map((m) => `
      <a class="mod-tab ${themeCls(m)}" role="tab" href="${base}/${m.id}" aria-current="${m.id === activeId}" aria-selected="${m.id === activeId}">
        ${m.art ? `<img src="${esc(m.art)}" alt="">` : ""}<span>${esc(m.title)}</span><span class="prog">${moduleMastered(m)}/${moduleTotal(m)}</span></a>`).join("")}</div>`;
  }
  function renderMissions(args) {
    renderTopbar("play");
    const m = mod(args[0]) || mod(lastModule) || DATA.modules[0];
    lastModule = m.id;
    const sel = args[1] || String(nextPlayableLevel(m).id);
    const levelIdx = m.levels.findIndex((l) => String(l.id) === sel);
    const showIntro = sel === "intro" || levelIdx < 0;
    const sideArt = m.id === "rt" ? "assets/linac.png" : m.art;
    const levelItems = m.levels.map((l, i) => {
      const unlocked = isUnlocked(m, i), b = best(m, l);
      return `<a class="lvl-item ${unlocked ? "" : "locked"}" href="#/missions/${m.id}/${l.id}" aria-current="${!showIntro && i === levelIdx}">
        <span class="ico">${unlocked ? I.play : I.lock}</span><span>Level ${esc(l.id)}<small>${esc(l.title)}</small></span>
        ${b ? `<span class="lv-stars">${starsHtml(b.stars)}</span>` : ""}</a>`;
    }).join("");
    let detail;
    if (showIntro) {
      detail = `<section class="panel detail intro-box"><h2 class="panel-title">${esc(m.title)}: Introduction</h2>
        <p>${esc(m.intro || m.summary || "")}</p>
        <p class="muted">${m.levels.length} levels · ${moduleTotal(m)} questions. Earn at least ${unlockMin()}★ on a level to unlock the next one.</p>
        <div class="actions"><a class="btn yellow" href="#/play/${m.id}/${nextPlayableLevel(m).id}">${I.play} Play Level ${esc(nextPlayableLevel(m).id)}</a></div></section>`;
    } else {
      const l = m.levels[levelIdx], unlocked = isUnlocked(m, levelIdx), b = best(m, l);
      const answered = new Map(((b && b.answers) || []).map((a) => [a.id, a.correct]));
      const next = m.levels[levelIdx + 1];
      detail = `<section class="panel detail">
        <div class="detail-head"><div><h2 class="panel-title">Level ${esc(l.id)}: ${esc(l.title)}</h2>${b ? starsHtml(b.stars) : starsHtml(0)}</div><span class="spacer"></span>
          <span class="score"><span class="star-on">${I.star}</span>${b ? b.correct : 0}/${l.questions.length}</span></div>
        <p class="desc">${esc(l.description || "")}</p>
        <div class="q-list">${l.questions.map((q, i) => {
          const st = answered.has(q.id) ? (answered.get(q.id) ? "ok" : "bad") : "none";
          return `<div class="q-row"><span class="st ${st === "ok" ? "star-on" : "star-off"}">${I.star}</span><span>Question ${i + 1}</span><span class="topic">${esc(q.topic || "")}</span>
            <span class="res ${st}">${st === "ok" ? "Correct" : st === "bad" ? "Missed" : unlocked ? "Not played" : "Locked"}</span>${unlocked ? "" : `<span aria-hidden="true">${I.lock.replace("<svg", '<svg width="18" height="18"')}</span>`}</div>`;
        }).join("")}</div>
        ${unlocked ? "" : `<div class="lock-note">${I.lock}<span>Earn at least ${unlockMin()}★ in Level ${esc(m.levels[levelIdx - 1].id)} to unlock this level.</span></div>`}
        <div class="actions">
          ${unlocked ? `<a class="btn yellow" href="#/play/${m.id}/${l.id}">${b ? I.retry + " Replay level" : I.play + " Start level"}</a>` : `<button class="btn yellow" disabled>${I.lock} Locked</button>`}
          ${next && isUnlocked(m, levelIdx + 1) ? `<a class="btn" href="#/missions/${m.id}/${next.id}">Next: Level ${esc(next.id)} ${I.next}</a>` : ""}
        </div></section>`;
    }
    view.innerHTML = `<div class="page ${themeCls(m)}">
      <a class="btn ghost back" href="#/home">${I.back} Back</a>
      ${moduleTabs(m.id, "#/missions")}
      <div class="missions">
        <aside class="panel side"><h2>${esc(m.title)}</h2>${sideArt ? `<div class="art"><img src="${esc(sideArt)}" alt=""></div>` : ""}
          <nav class="lvl-list" aria-label="${esc(m.title)} levels">
            <a class="lvl-item" href="#/missions/${m.id}/intro" aria-current="${showIntro}"><span class="ico">${I.intro}</span><span>Introduction</span></a>${levelItems}
          </nav></aside>
        ${detail}
      </div></div>`;
  }

  /* ================= GAMEPLAY ================= */
  function startSession(m, l) {
    const doShuffle = !DATA.settings || DATA.settings.shuffleOptions !== false;
    const order = l.questions.map((q) => {
      const opts = q.options.map((text, idx) => ({ text, correct: idx === q.answer }));
      return { q, opts: doShuffle ? shuffle(opts) : opts };
    });
    return { hash: location.hash, moduleId: m.id, levelId: l.id, order, i: 0, answers: [], picked: null, started: Date.now(), seconds: 0, finished: false, timer: null };
  }
  function stopTimer() { if (session && session.timer) { clearInterval(session.timer); session.timer = null; } }
  function renderPlay(args) {
    const m = mod(args[0]); const idx = m ? m.levels.findIndex((l) => String(l.id) === args[1]) : -1;
    if (!m || idx < 0) { toast("That mission does not exist."); return go("#/missions"); }
    if (!isUnlocked(m, idx)) { toast(`Level ${m.levels[idx].id} is locked. Earn ${unlockMin()}★ in the previous level first.`); return go(`#/missions/${m.id}/${m.levels[idx].id}`); }
    const l = m.levels[idx];
    if (!session || session.hash !== location.hash || session.finished) session = startSession(m, l);
    lastModule = m.id;
    renderTopbar("play");
    view.innerHTML = `<div class="page ${themeCls(m)}">
      <div class="panel play-head">
        <img class="thumb" src="${esc(m.id === "rt" ? "assets/linac.png" : m.art)}" alt="">
        <div class="t">${esc(m.title)}<small>Level ${esc(l.id)}: ${esc(l.title)}</small></div>
        <div class="pbar" role="progressbar" aria-label="Mission progress" aria-valuemin="0" aria-valuemax="${session.order.length}"><i id="pfill"></i></div>
        <div class="qcount" id="qcount"></div>
        <div class="timer" aria-label="Time elapsed">${I.clock}<span id="tval">00:00</span></div>
      </div>
      <div class="play">
        <div class="play-scene"><img src="assets/scene-physicist.png" alt=""></div>
        <div><section class="panel q-card" id="qcard" aria-live="polite"></section>
          <div class="play-foot"><button class="btn ghost sm" id="quit">${I.back} Quit to missions</button><span class="kbd-hint">Keys: A–D or 1–4 to answer · Enter for next</span></div></div>
      </div></div>`;
    document.getElementById("quit").onclick = () => (session.answers.length && !session.finished ? confirmLeave(`#/missions/${m.id}/${l.id}`) : go(`#/missions/${m.id}/${l.id}`));
    stopTimer();
    const tick = () => { session.seconds = Math.round((Date.now() - session.started) / 1000); const t = document.getElementById("tval"); if (t) t.textContent = fmtTime(session.seconds); };
    tick(); session.timer = setInterval(tick, 500);
    drawQuestion();
  }
  function drawQuestion() {
    const s = session, item = s.order[s.i], n = s.order.length;
    document.getElementById("qcount").textContent = `Question ${s.i + 1}/${n}`;
    document.getElementById("pfill").style.width = `${(s.answers.length / n) * 100}%`;
    document.querySelector(".pbar").setAttribute("aria-valuenow", s.answers.length);
    const card = document.getElementById("qcard");
    const answered = s.picked !== null;
    card.innerHTML = `<h2>${esc(item.q.question)}</h2>
      <div class="opts">${item.opts.map((o, k) => {
        let cls = "";
        if (answered) cls = o.correct ? "correct" : k === s.picked ? "wrong" : "dim";
        const mark = answered && o.correct ? I.checkCircle : answered && k === s.picked ? I.xCircle : "";
        return `<button class="opt ${cls}" data-k="${k}" ${answered ? "disabled" : ""} aria-label="Option ${"ABCD"[k] || k + 1}: ${esc(o.text)}${answered && o.correct ? " (correct answer)" : ""}">
          <span class="key">${"ABCDEFGH"[k]}</span><span class="txt">${esc(o.text)}</span>${mark ? `<span class="mark">${mark}</span>` : ""}</button>`;
      }).join("")}</div>
      ${answered ? feedbackHtml() : ""}`;
    card.querySelectorAll(".opt").forEach((b) => (b.onclick = () => choose(+b.dataset.k)));
    const nb = document.getElementById("next-q"); if (nb) { nb.onclick = nextQuestion; nb.focus({ preventScroll: true }); }
  }
  function feedbackHtml() {
    const s = session, item = s.order[s.i], ok = item.opts[s.picked].correct, last = s.i === s.order.length - 1;
    const right = item.opts.find((o) => o.correct).text;
    return `<div class="feedback ${ok ? "ok" : "bad"}" role="status">
      <span class="fico">${ok ? I.check : I.x}</span>
      <div><h3>${ok ? "Correct!" : "Not quite"}</h3>${ok ? "" : `<p><strong>Correct answer:</strong> ${esc(right)}</p>`}<p>${esc(item.q.explanation || "")}</p></div>
      <div class="act"><button class="btn" id="next-q">${last ? "See results" : "Next Question"} ${I.next}</button></div></div>`;
  }
  function choose(k) {
    const s = session; if (!s || s.picked !== null || s.finished) return;
    s.picked = k;
    const item = s.order[s.i];
    s.answers.push({ id: item.q.id, question: item.q.question, chosen: item.opts[k].text, answer: item.opts.find((o) => o.correct).text, correct: item.opts[k].correct, explanation: item.q.explanation || "" });
    drawQuestion();
  }
  function nextQuestion() {
    const s = session; if (!s || s.picked === null) return;
    if (s.i < s.order.length - 1) { s.i++; s.picked = null; drawQuestion(); document.getElementById("qcard").scrollIntoView({ block: "nearest" }); return; }
    finishSession();
  }
  function finishSession() {
    const s = session; stopTimer();
    s.seconds = Math.max(1, Math.round((Date.now() - s.started) / 1000));
    s.finished = true;
    const m = mod(s.moduleId), l = m.levels.find((x) => x.id === s.levelId);
    const correct = s.answers.filter((a) => a.correct).length, total = s.order.length, stars = starsFor(correct, total);
    const attempt = { moduleId: m.id, levelId: l.id, correct, total, stars, seconds: s.seconds, at: Date.now(), answers: s.answers };
    const { improved, previousBest } = Store.recordAttempt(attempt);
    const ctx = { attempt, improved };
    const newBadges = Store.awardBadges(BADGES.filter((b) => b.test(ctx)).map((b) => b.id));
    const idx = m.levels.indexOf(l);
    const nextLevel = m.levels[idx + 1] && isUnlocked(m, idx + 1) ? m.levels[idx + 1].id : null;
    Store.setLastResult({ ...attempt, newBadges, improved, previousBest: previousBest ? previousBest.correct : null, nextLevel });
    suppressGuard = true;
    go("#/results");
  }
  function keyHandler(e) {
    if (!session || session.finished || !location.hash.startsWith("#/play/") || modalRoot.firstChild) return;
    if (e.target && /INPUT|TEXTAREA|SELECT/.test(e.target.tagName)) return;
    const k = e.key.toLowerCase();
    const map = { a: 0, b: 1, c: 2, d: 3, 1: 0, 2: 1, 3: 2, 4: 3 };
    if (session.picked === null && k in map && map[k] < session.order[session.i].opts.length) { e.preventDefault(); choose(map[k]); }
    else if (session.picked !== null && (k === "enter" || k === "arrowright") && !(e.target && e.target.tagName === "BUTTON" && k === "enter")) { e.preventDefault(); nextQuestion(); }
  }
  document.addEventListener("keydown", keyHandler);
  function confirmLeave(target) {
    openModal(`<h2>Leave this mission?</h2><p class="muted">Your answers in this attempt will not be saved.</p>
      <div class="actions"><button class="btn ghost" data-close>Keep playing</button><button class="btn danger" id="leave-yes">Leave mission</button></div>`);
    document.getElementById("leave-yes").onclick = () => { stopTimer(); session = null; closeModal(); suppressGuard = true; location.hash = target; };
  }

  /* ================= RESULTS ================= */
  function renderResults() {
    renderTopbar("play");
    const r = Store.lastResult();
    if (!r || !mod(r.moduleId)) {
      view.innerHTML = `<div class="page"><div class="state-screen"><h2>No results yet</h2><p>Finish a mission to see your score here.</p><a class="btn yellow" href="#/missions">${I.play} Choose a mission</a></div></div>`;
      return;
    }
    const m = mod(r.moduleId), l = m.levels.find((x) => x.id === r.levelId) || { id: r.levelId, title: "" };
    const passed = r.stars >= unlockMin();
    const msg = r.stars === 3 ? "Outstanding! Your patients are in safe hands." : passed ? "Great job! You're making a difference in patient care!" : "Good effort! Review the answers and try again.";
    const nb = (r.newBadges || []).map((id) => BADGES.find((b) => b.id === id)).filter(Boolean);
    view.innerHTML = `<div class="page ${themeCls(m)}">
      <div class="results">
        <div class="res-scene ${passed ? "" : "fail"}"><img src="assets/scene-results.png" alt="Medical physicist celebrating next to a trophy"><div class="bubble">${esc(msg)}</div></div>
        <div class="res-main">
          <div class="big-stars" role="img" aria-label="${r.stars} of 3 stars">${[0, 1, 2].map((i) => `<span class="${i < r.stars ? "star-on" : "star-off"}">${I.star}</span>`).join("")}</div>
          <h1 class="res-title">${passed ? `Level ${esc(l.id)} Complete!` : `Level ${esc(l.id)}: Try Again`}</h1>
          <div class="panel score-box">Score: ${r.correct}/${r.total}</div>
          <div class="panel stat-box">
            <div class="stat"><span style="color:var(--ok-2)">${I.check}</span>Correct answers<b>${r.correct}</b></div>
            <div class="stat"><span style="color:#ff6b70">${I.xCircle}</span>Incorrect answers<b>${r.total - r.correct}</b></div>
            <div class="stat"><span style="color:#cfe3ff">${I.clock}</span>Time taken<b>${fmtLong(r.seconds)}</b></div>
            ${r.previousBest != null ? `<div class="stat"><span class="star-on">${I.star}</span>Previous best<b>${r.previousBest}/${r.total}</b></div>` : ""}
          </div>
          ${nb.length ? `<div><p style="margin:4px 0 8px;font-weight:900">New badge${nb.length > 1 ? "s" : ""} earned!</p><div class="new-badges">${nb.map((b) => `<span class="badge-chip">${badgeHtml(b)}${esc(b.name)}</span>`).join("")}</div></div>` : ""}
          ${!passed ? `<p class="muted" style="margin:0">Earn at least ${unlockMin()}★ (${minCorrectFor(unlockMin(), r.total)}/${r.total} correct) to unlock the next level.</p>` : ""}
          <div class="res-actions">
            <button class="btn" id="review-btn" aria-expanded="false">${I.play} Review Answers</button>
            <a class="btn ghost" href="#/play/${m.id}/${l.id}">${I.retry} Retry</a>
            ${r.nextLevel != null ? `<a class="btn yellow" href="#/play/${m.id}/${r.nextLevel}">Next Level ${I.next}</a>` : `<a class="btn yellow" href="#/missions/${m.id}">Missions ${I.next}</a>`}
            <a class="btn ghost" href="#/home">${I.home} Dashboard</a>
          </div>
        </div>
      </div>
      <section class="panel review" id="review" hidden><h2 class="panel-title">Review answers</h2>
        ${(r.answers || []).map((a, i) => `<div class="review-item"><h4><span style="color:${a.correct ? "var(--ok-2)" : "#ff6b70"}">${a.correct ? I.checkCircle : I.xCircle}</span>${i + 1}. ${esc(a.question)}</h4>
          <p><strong>Your answer:</strong> ${esc(a.chosen)}</p>${a.correct ? "" : `<p><strong>Correct answer:</strong> ${esc(a.answer)}</p>`}<p>${esc(a.explanation)}</p></div>`).join("") || `<div class="empty">No answers recorded.</div>`}
      </section></div>`;
    const rb = document.getElementById("review-btn"), rv = document.getElementById("review");
    rb.onclick = () => { rv.hidden = !rv.hidden; rb.setAttribute("aria-expanded", String(!rv.hidden)); if (!rv.hidden) rv.scrollIntoView({ behavior: "smooth", block: "start" }); };
  }
  function minCorrectFor(stars, total) { for (let c = 0; c <= total; c++) if (starsFor(c, total) >= stars) return c; return total; }

  /* ================= LEADERBOARD ================= */
  function scoreRows(period) {
    const now = new Date(), y = now.getFullYear(), mo = now.getMonth();
    return Store.players().map((p) => {
      let score = 0, stars = 0, seconds = 0;
      if (period === "month") {
        const bestBy = {};
        p.attempts.filter((a) => { const d = new Date(a.at); return d.getFullYear() === y && d.getMonth() === mo; })
          .forEach((a) => { const k = a.moduleId + "-" + a.levelId; const b = bestBy[k]; if (!b || a.correct > b.correct || (a.correct === b.correct && a.seconds < b.seconds)) bestBy[k] = a; });
        Object.values(bestBy).forEach((a) => { score += a.correct; stars += a.stars; seconds += a.seconds; });
      } else {
        Object.values(p.best).forEach((b) => { score += b.correct; stars += b.stars; seconds += b.seconds; });
      }
      return { p, score, stars, seconds, played: p.attempts.length > 0 };
    }).filter((r) => r.played && (period !== "month" || r.score + r.stars > 0 || r.seconds > 0))
      .sort((a, b) => b.score - a.score || b.stars - a.stars || a.seconds - b.seconds || a.p.name.localeCompare(b.p.name));
  }
  function avatarFor(p, isMe) {
    if (isMe) return `<img class="av" src="assets/avatar.png" alt="">`;
    const hue = [...p.id].reduce((a, c) => a + c.charCodeAt(0), 0) % 360;
    return `<span class="av" style="background:hsl(${hue} 70% 45%)" aria-hidden="true">${esc((p.name.trim()[0] || "?").toUpperCase())}</span>`;
  }
  function renderLeaderboard(args) {
    renderTopbar("leaderboard");
    const tab = ["month", "all", "me"].includes(args[0]) ? args[0] : "month";
    const me = Store.player();
    const tabs = [["month", "This Month"], ["all", "All Time"], ["me", "My Rank"]].map(([k, l]) => `<a class="tab" role="tab" href="#/leaderboard/${k}" aria-selected="${k === tab}">${l}</a>`).join("");
    let body;
    if (tab === "me") {
      const all = scoreRows("all"), pos = all.findIndex((r) => r.p.id === me.id);
      const earned = BADGES.filter((b) => me.badges[b.id]);
      body = `<p style="font-weight:900;font-size:18px;margin:4px 0 14px">${pos >= 0 ? `You are ranked #${pos + 1} of ${all.length} on this device · ${all[pos].score} points · ${totalStars()}★` : "Play a mission to get your first ranking."}</p>
        <div class="my-mods">${DATA.modules.map((m) => { const d = moduleMastered(m), t = moduleTotal(m); return `<div class="my-mod ${themeCls(m)}"><h3>${esc(m.title)}</h3>
          <div class="row"><span class="star-on" style="width:18px;display:inline-flex">${I.star}</span><b>${d}/${t}</b><span class="spacer"></span>${m.levels.map((l) => starsHtml((best(m, l) || { stars: 0 }).stars)).join(" ")}</div>
          <div class="bar"><i style="width:${(d / t) * 100}%"></i></div></div>`; }).join("")}</div>
        <h3 style="margin:0 0 10px;font-weight:900">Badges (${earned.length}/${BADGES.length})</h3>
        <div class="badge-grid">${BADGES.map((b) => `<div class="badge-card">${badgeHtml(b, !!me.badges[b.id], true)}<div><b>${esc(b.name)}</b><span>${me.badges[b.id] ? "Earned " + new Date(me.badges[b.id]).toLocaleDateString() : esc(b.desc)}</span></div></div>`).join("")}</div>`;
    } else {
      const rows = scoreRows(tab);
      body = rows.length ? `<table class="lb-table"><thead><tr><th>Rank</th><th>Player</th><th>Score</th><th>Badges</th></tr></thead><tbody>
        ${rows.map((r, i) => { const isMe = r.p.id === me.id; const bs = BADGES.filter((b) => r.p.badges[b.id]);
          return `<tr class="${isMe ? "me" : ""}"><td><span class="rank ${i < 3 ? "r" + (i + 1) : ""}">${i + 1}</span></td>
          <td><span class="player-cell">${avatarFor(r.p, isMe)}${esc(r.p.name)}${isMe ? ' <span class="sr-only">(you)</span>' : ""}</span></td>
          <td>${r.score}</td><td><span class="badge-row">${bs.slice(0, 5).map((b) => badgeHtml(b)).join("")}${bs.length > 5 ? `<span class="muted">+${bs.length - 5}</span>` : ""}${bs.length ? "" : '<span class="muted">—</span>'}</span></td></tr>`; }).join("")}
        </tbody></table>` : `<div class="empty">${tab === "month" ? "No missions played this month yet." : "No missions played yet."} <br><br><a class="btn yellow sm" href="#/missions">${I.play} Play a mission</a></div>`;
    }
    view.innerHTML = `<div class="page"><section class="panel lb">
      <div class="lb-head"><img src="assets/trophy-small.png" alt=""><h1 class="panel-title">Leaderboard</h1><span class="spacer"></span><div class="tabs" role="tablist">${tabs}</div></div>
      ${body}
      <p class="note">Score = best correct answers per level. Rankings include every player profile on this device (switch or add players from your profile). A shared cross-device leaderboard needs a backend; see the README.</p>
      <div class="row" style="margin-top:12px"><button class="btn ghost sm" id="lb-profile">${I.user} Manage players</button></div>
    </section></div>`;
    document.getElementById("lb-profile").onclick = openProfile;
  }

  /* ================= RESOURCES ================= */
  function renderResources(args) {
    renderTopbar("resources");
    const m = mod(args[0]) || mod(lastModule) || DATA.modules[0];
    const cats = [["concepts", "Key Concepts", "Notes and summaries", I.doc], ["guidelines", "Guidelines", "IAEA, AAPM, ICRP and more", I.book], ["cases", "Case Studies", "Real-world examples", I.folder], ["videos", "Videos", "Lecture and course libraries", I.video]];
    const cat = cats.some((c) => c[0] === args[1]) ? args[1] : "concepts";
    let content = "";
    if (!RES && cat !== "cases") content = `<div class="empty">Learning materials could not be loaded. Case studies are still available.</div>`;
    else if (cat === "concepts") {
      const list = (RES.modules[m.id] && RES.modules[m.id].concepts) || [];
      content = list.length ? `<div class="concepts">${list.map((c) => `<article class="concept"><h3>${esc(c.title)}</h3><p>${esc(c.text)}</p></article>`).join("")}</div>` : `<div class="empty">No key concepts added for this module yet.</div>`;
    } else if (cat === "guidelines") {
      const list = (RES.guidelines || []).filter((g) => g.module === m.id);
      content = list.length ? `<div class="links">${list.map((g) => `<a class="link" href="${esc(g.url)}" target="_blank" rel="noopener noreferrer"><span class="org">${esc(g.org)}</span>${esc(g.title)}${I.ext}</a>`).join("")}</div>` : `<div class="empty">No guidelines listed for this module yet.</div>`;
    } else if (cat === "videos") {
      const list = RES.videos || [];
      content = list.length ? `<div class="links">${list.map((g) => `<a class="link" href="${esc(g.url)}" target="_blank" rel="noopener noreferrer"><span class="org">${esc(g.org)}</span>${esc(g.title)}${I.ext}</a>`).join("")}</div>` : `<div class="empty">No video libraries listed yet.</div>`;
    } else {
      const qs = m.levels.slice(1).flatMap((l) => l.questions.map((q) => ({ q, l })));
      const pool = qs.length ? qs : m.levels.flatMap((l) => l.questions.map((q) => ({ q, l })));
      content = pool.map(({ q, l }) => `<article class="case"><h3>${esc(q.topic || "Scenario")} <span class="muted" style="font-size:13px">· Level ${esc(l.id)}</span></h3><p>${esc(q.question)}</p>
        <details><summary>Show answer and explanation</summary><p><strong>${esc(q.options[q.answer])}</strong></p><p>${esc(q.explanation || "")}</p></details></article>`).join("") || `<div class="empty">No case studies yet.</div>`;
    }
    view.innerHTML = `<div class="page"><section class="panel lb">
      <div class="lb-head"><h1 class="panel-title">Learning Resources</h1></div>
      ${moduleTabs(m.id, "#/resources").replace(/href="#\/resources\/(\w+)"/g, `href="#/resources/$1/${cat}"`)}
      <div class="res-cats">${cats.map(([k, t, s, ic]) => `<a class="res-cat" href="#/resources/${m.id}/${k}" aria-pressed="${k === cat}">${ic}<span><b>${t}</b><span>${s}</span></span></a>`).join("")}</div>
      ${content}
      ${RES && RES.note && (cat === "guidelines" || cat === "videos") ? `<p class="note">${esc(RES.note)}</p>` : ""}
    </section></div>`;
    lastModule = m.id;
  }

  /* ================= ABOUT ================= */
  function renderAbout() {
    renderTopbar("about");
    const qCount = DATA.modules.reduce((a, m) => a + moduleTotal(m), 0);
    view.innerHTML = `<div class="page"><div class="about">
      <div>
        <section class="panel"><h1 class="panel-title">About Medical Physics Quest</h1>
          <p>Medical Physics Quest turns real-world medical physics challenges into short missions. It is designed for students, residents, radiographers, radiation therapists and anyone learning how physics keeps patients and staff safe.</p>
          <h3>How to play</h3>
          <ul><li>Pick a module: Radiation Therapy, Diagnostic Imaging, Radiation Protection or Quality Control.</li>
            <li>Each level has multiple-choice questions with instant feedback and an explanation.</li>
            <li>Earn up to 3★ per level (90% for 3★, 70% for 2★, 50% for 1★). At least ${unlockMin()}★ unlocks the next level.</li>
            <li>Collect badges and climb the leaderboard. Progress is saved in this browser.</li></ul>
          <h3>What's inside</h3>
          <p>${DATA.modules.length} modules · ${DATA.modules.reduce((a, m) => a + m.levels.length, 0)} levels · ${qCount} questions covering dosimetry, image quality, QC testing, radiation protection, troubleshooting and safe return to clinical service.</p>
          <h3>For educators</h3>
          <p>All questions live in <code>data/questions.json</code> and learning materials in <code>data/resources.json</code>. Edit or add questions there without touching the game code; the README explains the format and includes a validation script.</p>
        </section>
        <section class="panel disclaimer" style="margin-top:16px"><h3>Educational disclaimer</h3>
          <p>This game is for education and training only. It is not clinical guidance and does not replace professional judgement, institutional procedures, manufacturer instructions or the regulations that apply where you work. Tolerances and limits quoted are illustrative or taken from international recommendations; always follow your local protocols and qualified medical physicist.</p></section>
      </div>
      <aside class="panel team"><img src="assets/scene-team.png" alt="Two cartoon medical physicists with a tablet"><p style="margin:12px 0 0">Learn · Solve · Apply · Level Up</p>
        <div class="row" style="margin-top:12px;flex-wrap:wrap"><a class="btn yellow" href="#/missions">${I.play} Start Game</a><a class="btn ghost" href="#/resources">${I.book} Resources</a></div></aside>
    </div></div>`;
  }

  /* ================= PROFILE / MODALS ================= */
  function openModal(html) {
    modalRoot.innerHTML = `<div class="modal-back"><div class="panel modal" role="dialog" aria-modal="true">${html}</div></div>`;
    const back = modalRoot.firstChild;
    back.addEventListener("click", (e) => { if (e.target === back || e.target.closest("[data-close]")) closeModal(); });
    const first = back.querySelector("input, button, select"); if (first) first.focus();
  }
  function closeModal() { modalRoot.innerHTML = ""; }
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && modalRoot.firstChild) closeModal(); });

  function openProfile() {
    const p = Store.player(), players = Store.players();
    openModal(`<h2>Player profile</h2>
      ${Store.storageOk ? "" : `<p class="err">Browser storage is unavailable, so progress will be lost when you close this page.</p>`}
      <label for="pname">Display name</label><input id="pname" maxlength="24" value="${esc(p.name)}" autocomplete="off">
      <div class="err" id="perr" hidden></div>
      <p class="muted" style="margin:8px 0 0">Level ${playerLevel()} · ${totalStars()}★ · ${Object.keys(p.badges).length} badges</p>
      <hr>
      <label for="pswitch">Players on this device</label>
      <select id="pswitch">${players.map((x) => `<option value="${esc(x.id)}" ${x.id === p.id ? "selected" : ""}>${esc(x.name)}</option>`).join("")}</select>
      <div class="actions" style="justify-content:flex-start;margin-top:10px"><button class="btn ghost sm" id="pnew">${I.user} New player</button><button class="btn ghost sm" id="preset">${I.retry} Reset my progress</button>${players.length > 1 ? `<button class="btn ghost sm" id="pdel">Remove this player</button>` : ""}</div>
      <div class="actions"><button class="btn ghost" data-close>Cancel</button><button class="btn yellow" id="psave">Save</button></div>`);
    const err = (m) => { const e = document.getElementById("perr"); e.textContent = m; e.hidden = !m; };
    const valid = (v) => (v.trim().length ? "" : "Please enter a name.");
    document.getElementById("psave").onclick = () => { const v = document.getElementById("pname").value; const e = valid(v); if (e) return err(e); Store.rename(v.trim()); closeModal(); render(); toast("Profile saved"); };
    document.getElementById("pswitch").onchange = (e) => { Store.switchPlayer(e.target.value); closeModal(); render(); toast(`Now playing as ${Store.player().name}`); };
    document.getElementById("pnew").onclick = () => { const v = document.getElementById("pname").value.trim(); const name = v && v !== p.name ? v : `Player ${Store.players().length + 1}`; Store.createPlayer(name); closeModal(); render(); toast(`Created ${name}. Tip: rename in your profile.`); };
    const reset = document.getElementById("preset");
    reset.onclick = () => { if (reset.dataset.armed) { Store.resetProgress(); closeModal(); render(); toast("Progress reset"); } else { reset.dataset.armed = "1"; reset.classList.add("danger"); reset.innerHTML = "Click again to confirm reset"; } };
    const del = document.getElementById("pdel");
    if (del) del.onclick = () => { if (del.dataset.armed) { Store.deletePlayer(p.id); closeModal(); render(); toast("Player removed"); } else { del.dataset.armed = "1"; del.classList.add("danger"); del.textContent = "Click again to remove"; } };
  }

  boot();
})();
